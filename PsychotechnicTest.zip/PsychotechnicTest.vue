<script setup>
import Applayout from '@/Layouts/Applayout.vue';
import { reactive, computed} from "vue";
import { useForm } from '@inertiajs/vue3';

const form = useForm({
    test1 : '',
    test2 : '',
    test3 : '',
    test4 : '',
    test5 : '',
    test6 : '',
    test7 : '',

    moyenne : '',
    status : '',
});


function CalculMoyenne() {
    form.moyenne = parseFloat((Number(form.test1) + 
    Number(form.test2) +
    Number(form.test3) +
    Number(form.test4) +
    Number(form.test5) +
    Number(form.test6) +
    Number(form.test7)) / 7)

  if (form.moyenne < 10) {
     form.status = "Rejeter";
  } else if (form.moyenne > 10 && form.moyenne < 15 ) {
    form.status = "Passable";
  } else {
    form.status = "Accepter";
  }
}



</script>

<template>
    <Applayout>
        <form @submit.prevent="form.post(route('psychotechnic.test'))">
            <div class="border border-black mx-3 my-3">
                <h2 class="text-center bg-[#be8719]"> Test Psychotechnique </h2>
                <div class="grid grid-cols-3 p-2 gap-2">
                    <div class="flex justify-between items-center mb-2">
                        <label for="test1"> Test 1 :  </label>
                        <input type="number" name="test1" id="test1" v-model="form.test1">
                    </div>
                    <div class="flex justify-between items-center mb-2">
                        <label for="test2"> Test 2 :  </label>
                        <input type="number" name="test2" id="test2" v-model="form.test2">
                    </div>
                    <div class="flex justify-between items-center mb-2">
                        <label for="test3"> Test 3 : </label>
                        <input type="number" name="test3" id="test3" v-model="form.test3">
                    </div>
                    <div class="flex justify-between items-center mb-2">
                        <label for="test4"> Test 4 :  </label>
                        <input type="number" name="test4" id="test4" v-model="form.test4">
                    </div>
                    <div class="flex justify-between items-center mb-2">
                        <label for="test5"> Test 5 :  </label>
                        <input type="number" name="test5" id="test5" v-model="form.test5">
                    </div>
                    <div class="flex justify-between items-center mb-2">
                        <label for="test6"> Test 6 :  </label>
                        <input type="number" name="test6" id="test6" v-model="form.test6">
                    </div>
                    <div class="flex justify-between items-center mb-2">
                        <label for="test7"> Test 7 : </label>
                        <input type="number" name="test7" id="test7" v-model="form.test7" @input="CalculMoyenne">
                    </div>
                </div>
            </div>
            <div class="border border-black mx-3 my-3">
                <div class="grid grid-cols-2 p-2 gap-5">
                    <div class="flex justify-between items-center mb-2">
                        <label for=""> Moyenne </label>
                        <input type="text" name="" id="" readonly :value="form.moyenne">
                    </div>
            
                    <div class="flex justify-between items-center mb-2">
                        <label for=""> Status </label>
                        <input type="text" name="" id="" readonly :value="form.status">
                    </div>
                </div>
                <!-- test :  {{ form.test7 }}
                test :  {{ form.test6 }}
                moyenne : {{ form.moyenne }}
                Status : {{ form.status }} -->
            </div>
            <button type="submit" class="border border-green-200 bg-green-200 hover:bg-green-500"> Soumettre </button>
        </form>
    </Applayout>
</template>